PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS employers (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT, phone_private TEXT NOT NULL,
 district TEXT, verification_status TEXT NOT NULL DEFAULT 'pending' CHECK(verification_status IN ('pending','verified','rejected')),
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, employer_id TEXT REFERENCES employers(id), title TEXT NOT NULL,
 company TEXT NOT NULL, district TEXT NOT NULL, location TEXT NOT NULL, salary TEXT NOT NULL,
 work_type TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL,
 contact_private TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','closed')),
 verified INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jobs_status_district ON jobs(status,district);
CREATE INDEX IF NOT EXISTS idx_jobs_category ON jobs(category);
CREATE TABLE IF NOT EXISTS workers (
 id TEXT PRIMARY KEY, full_name TEXT NOT NULL, phone_private TEXT NOT NULL UNIQUE,
 district TEXT, skills TEXT, experience_years INTEGER DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS applications (
 id TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES jobs(id), worker_id TEXT NOT NULL REFERENCES workers(id),
 status TEXT NOT NULL DEFAULT 'applied' CHECK(status IN ('applied','shortlisted','rejected','hired')),
 created_at TEXT NOT NULL, UNIQUE(job_id,worker_id)
);
CREATE TABLE IF NOT EXISTS reports (
 id TEXT PRIMARY KEY, job_id TEXT REFERENCES jobs(id), reporter_contact_private TEXT,
 reason TEXT NOT NULL, details TEXT, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);
