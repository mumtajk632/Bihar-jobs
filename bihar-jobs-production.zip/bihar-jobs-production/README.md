# BIHAR JOBS — production starter (0.1.0)

A production-oriented foundation for a Bihar district-level jobs platform. This is source code, not a deployed/live service. The browser UI currently supports bilingual job discovery, filters, employer job-submission form, and safety guidance. The Worker API reads approved jobs and accepts new posts into a pending moderation state. D1 schema includes employers, jobs, workers, applications and reports.

## Important launch blockers
- No live domain is registered by this project.
- No Cloudflare account, D1 database, API secrets, OTP provider, email provider, or admin identity has been configured.
- Authentication, employer identity verification, admin review UI, applications, rate limiting, CAPTCHA/abuse controls, privacy/terms pages, and legal review must be completed before accepting real users.
- Do not collect Aadhaar or sensitive identity documents in the MVP.
- Do not publish seed listings as genuine vacancies; they are clearly illustrative starter content and should be removed before public launch.

## Local frontend
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`

## Cloudflare API setup
1. Create a Cloudflare account and a D1 database named `bihar-jobs-db`.
2. Copy its database ID into `wrangler.toml`.
3. `npx wrangler login`
4. `npm run db:remote`
5. `npm run cf:deploy`
6. Configure a same-origin Worker route or frontend proxy to `/api/*` before production use.

## Security note
The included API is a scaffold only. It intentionally has no public admin endpoint. Before production, add authentication, server-side role checks, rate limiting, abuse prevention, input validation, structured logging, backups, and security review. Do not use it to process real worker/employer personal data until these are implemented.
