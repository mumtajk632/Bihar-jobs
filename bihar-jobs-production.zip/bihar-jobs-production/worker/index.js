const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const clean=s=>String(s??'').trim().slice(0,2000);
export default {
 async fetch(request,env){
  const url=new URL(request.url); const path=url.pathname;
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{'access-control-allow-origin':url.origin,'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'}});
  if(path==='/api/health')return json({ok:true,service:'BIHAR JOBS API',version:'0.1.0'});
  if(path==='/api/jobs'&&request.method==='GET'){
   try{const {results=[]}=await env.DB.prepare("SELECT id,title,company,district,location,salary,work_type AS type,category,description,status,verified,created_at FROM jobs WHERE status='approved' ORDER BY created_at DESC LIMIT 100").all();return json({jobs:results});}catch(e){return json({error:'Database not initialized'},503)}
  }
  if(path==='/api/jobs'&&request.method==='POST'){
   let body;try{body=await request.json()}catch{return json({error:'Invalid JSON'},400)}
   const fields=['title','company','district','location','salary','type','category','description','contact'];for(const f of fields){if(!clean(body[f]))return json({error:`Missing ${f}`},400)}
   if(clean(body.title).length>120||clean(body.company).length>160||clean(body.description).length>2000)return json({error:'Field too long'},400);
   const id=crypto.randomUUID();const now=new Date().toISOString();
   try{await env.DB.prepare('INSERT INTO jobs (id,title,company,district,location,salary,work_type,category,description,contact_private,status,verified,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?)').bind(id,clean(body.title),clean(body.company),clean(body.district),clean(body.location),clean(body.salary),clean(body.type),clean(body.category),clean(body.description),clean(body.contact),'pending',now).run();return json({id,status:'pending'},201)}catch(e){return json({error:'Could not save job. Check database setup.'},503)}
  }
  return json({error:'Not found'},404);
 }
};
